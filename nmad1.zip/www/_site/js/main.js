window.onload = function () {
    
$('#running').click(function(){    
document.location.href = "../running/index.html";
});
    
$('#pooping').click(function(){    
document.location.href = "../pooping/index.html";
});
    
$('#swimming').click(function(){    
document.location.href = "../swimming/index.html";
});    

$('#king').click(function(){    
document.location.href = "../achievements/index.html";
});
    
};