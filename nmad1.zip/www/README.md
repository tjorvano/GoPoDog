## Go Po Dog



## Kevin Tresinie en Tjörven Van Opstaele


##Link naar de website

https://kevitres.github.io/

## Deployen

Je moet naar de root gaan met je terminal en daarop jekyll serve commando uitvoeren. 
Als je naar je browser gaat en je vult de url localhost:4000 in, dan zie je de website lokaal.

Je kan het ook online zien via bovenstaande link.

## Beschrijving projecten

Alles is gemaakt volgens de structuur van jekyll.

app.js zorgt ervoor dat je je kan registreren en inloggen (adhv een database)
maps.js is alle code achter de maps en markers
main.js zorgt voor enkele functionaliteiten 

Pooping,Swimming en Running zijn dir's waarin zich een index.html bevindt (dit is gedaan voor een schonere url te bekomen). Deze zijn gemaakt a.d.h.v default.html
Dit is het template file voor desbetreffende bestanden

De achievement pagina is niet volledig klaar geraakt. Maar je vindt daar een image array terug. En als je op een image klikt dat zou je normaal de nog behaalde achievement zien.

De index.html in de root heeft de layout van homepage.html

Er is een grote main.css file. Deze gemaakt adhv main.scss die je ook kan terugvinden in de map css

Er is een mag img met alle nodige afbeeldingen.

## Opleidingsinstelling Arteveldehogeschool